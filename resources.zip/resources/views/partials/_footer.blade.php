<div id="footer">
    <div class="footer_desno">
    	<h3>CS Logistik GmbH</h3>
    	<p><span style="font-weight:bold;">Adress:</span><span style="margin-left:20px; color:#fff;">Unterfeldstrasse 15, 4410 Liestal, Schweiz</span>
    	</p>
    	<p><span style="font-weight:bold;">Tel:</span><span style="margin-left:45px; color:#fff;">+41 (0) 61 905 16 50</span>
    	</p>
    	<p><span style="font-weight:bold;">Fax:</span><span style="margin-left:42px; color:#fff;">+41 (0) 61 905 16 59</span>
    	</p>
    </div>
    <div class="vrati_na_pocetak">
    	<a href="#navigation">Zurück nach oben &nbsp;&nbsp;&nbsp;<i class="fa fa-angle-up" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;</a>
    </div>
</div>
@include('partials._scripts')
@yield('scripts')