<p>Klicken Sie diesen Link, um Ihr Passwort zurückzusetzen:</p>
<br>
<a href="{{ $actionUrl }}">{{ $actionUrl }}</a>