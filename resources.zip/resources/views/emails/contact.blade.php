Name: {{ $data->name }}<br>
Emailadresse: {{ $data->email }}<br><br>

Betreff: {{ $data->subject }}<br>
Nachricht: <br>{{ $data->comment }}